import en from './en';
import ko from './ko';

export default {
  GMS: en,
  KMS: ko
}
