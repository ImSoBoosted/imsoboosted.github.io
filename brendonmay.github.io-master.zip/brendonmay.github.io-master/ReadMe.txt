Visual Studio Code
Extensions:
	- Debugger for chrome (launch.json has config options)